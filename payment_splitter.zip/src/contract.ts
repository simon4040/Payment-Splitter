import artifact from '../contracts/out/SplitFactory.sol/SplitFactory.json'

export const SPLIT_FACTORY = {
  address: '0x20b1f718b7a612f605414bc47c5a2abdde1659cc' as const,
  abi: artifact.abi,
} as const

export const ARC_TESTNET_USDC = '0x3600000000000000000000000000000000000000' as const
export const ARC_TESTNET_ID = 5042002 as const
